#!/bin/bash
set -eu
cd "$(dirname "$0")/../.."
work/mt32-build-tools/cmake/data/bin/cmake -S work/munt/mt32emu -B work/mt32-wasm-build \
  -DCMAKE_TOOLCHAIN_FILE="$PWD/work/emsdk/upstream/emscripten/cmake/Modules/Platform/Emscripten.cmake" \
  -DCMAKE_BUILD_TYPE=Release -Dlibmt32emu_SHARED=OFF -Dlibmt32emu_C_INTERFACE=OFF -DBUILD_TESTING=OFF
work/mt32-build-tools/cmake/data/bin/cmake --build work/mt32-wasm-build -j 4
work/emsdk/upstream/emscripten/em++ work/mt32-browser/bridge.cpp work/mt32-wasm-build/libmt32emu.a \
  -Iwork/mt32-wasm-build/include -std=c++14 -O2 \
  -sMODULARIZE=1 -sEXPORT_ES6=1 -sALLOW_MEMORY_GROWTH=1 -sENVIRONMENT=web,worker,node \
  '-sEXPORTED_RUNTIME_METHODS=["HEAPU8","HEAPF32"]' \
  '-sEXPORTED_FUNCTIONS=["_malloc","_free","_stunts_mt32_open","_stunts_mt32_close","_stunts_mt32_reset_count","_stunts_mt32_display","_stunts_mt32_read","_stunts_mt32_main_display","_stunts_mt32_patch_name","_stunts_mt32_sound","_stunts_mt32_setting","_stunts_mt32_set","_stunts_mt32_sample_rate","_stunts_mt32_active","_stunts_mt32_flush","_stunts_mt32_reset_controllers","_stunts_mt32_midi","_stunts_mt32_render"]' \
  -o work/mt32-browser/munt.mjs
node work/mt32-browser/check.mjs
