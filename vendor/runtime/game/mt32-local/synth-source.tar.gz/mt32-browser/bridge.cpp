// Local Munt integration prototype. No Roland ROM data is included.
#include <mt32emu/mt32emu.h>
#include <vector>
#include <memory>
#include <cstdint>

namespace {
struct Reporter : MT32Emu::ReportHandler {
  bool overflow = false;
  MT32Emu::Synth *synth = nullptr;
  uint32_t resetCount = 0;
  void onDeviceReset() override { ++resetCount; }
  bool onMIDIQueueOverflow() override {
    // Native pause/seek can emit untimed bursts faster than the emulated
    // serial wire. Apply already queued messages in order, then let Munt
    // retry the unqueued message. Never drop it or replay the whole batch.
    if (synth) { synth->flushMIDIQueue(); return true; }
    overflow = true; return false;
  }
};
struct Instance {
  Reporter reporter;
  std::vector<uint8_t> control, pcm;
  std::unique_ptr<MT32Emu::ArrayFile> controlFile, pcmFile;
  const MT32Emu::ROMImage *controlImage = nullptr, *pcmImage = nullptr;
  std::unique_ptr<MT32Emu::Synth> synth;
  std::unique_ptr<MT32Emu::DefaultMidiStreamParser> parser;
  ~Instance() {
    parser.reset();
    synth.reset();
    if (controlImage) MT32Emu::ROMImage::freeROMImage(controlImage);
    if (pcmImage) MT32Emu::ROMImage::freeROMImage(pcmImage);
  }
};
std::unique_ptr<Instance> instance;
}

extern "C" {
// Errors: 1 invalid arguments, 2 unrecognized control, 3 unrecognized PCM,
// 4 incompatible pair. A failed replacement leaves the running synth intact.
int stunts_mt32_open(const uint8_t *control, uint32_t controlSize,
                    const uint8_t *pcm, uint32_t pcmSize) {
  if (!control || !pcm || !controlSize || !pcmSize ||
      controlSize > 1048576 || pcmSize > 4194304) return 1;
  auto next = std::make_unique<Instance>();
  next->control.assign(control, control + controlSize);
  next->pcm.assign(pcm, pcm + pcmSize);
  next->controlFile = std::make_unique<MT32Emu::ArrayFile>(next->control.data(), controlSize);
  next->pcmFile = std::make_unique<MT32Emu::ArrayFile>(next->pcm.data(), pcmSize);
  next->controlImage = MT32Emu::ROMImage::makeROMImage(next->controlFile.get());
  auto info = next->controlImage ? next->controlImage->getROMInfo() : nullptr;
  if (!info || info->type != MT32Emu::ROMInfo::Control || info->pairType != MT32Emu::ROMInfo::Full) return 2;
  next->pcmImage = MT32Emu::ROMImage::makeROMImage(next->pcmFile.get());
  info = next->pcmImage ? next->pcmImage->getROMInfo() : nullptr;
  if (!info || info->type != MT32Emu::ROMInfo::PCM || info->pairType != MT32Emu::ROMInfo::Full) return 3;
  next->synth = std::make_unique<MT32Emu::Synth>(&next->reporter);
  if (!next->synth->open(*next->controlImage, *next->pcmImage)) return 4;
  next->reporter.synth = next->synth.get();
  next->parser = std::make_unique<MT32Emu::DefaultMidiStreamParser>(*next->synth);
  instance = std::move(next);
  return 0;
}
void stunts_mt32_close() { instance.reset(); }
uint32_t stunts_mt32_reset_count() { return instance ? instance->reporter.resetCount : 0; }
int stunts_mt32_display(char *text) {
  if (!text) return -1;
  if (!instance) { text[0] = 0; return -1; }
  return instance->synth->getDisplayState(text) ? 1 : 0;
}
int stunts_mt32_read(unsigned address, unsigned length, uint8_t *target) {
 if (!instance || !target || length>256 || address>0x1fffff) return 1;
 instance->synth->readMemory(address,length,target);return 0;
}
int stunts_mt32_sound(unsigned group, unsigned number, char *target) {
 if (!instance || !target || group>3 || number>127) return 1;
 if (!instance->synth->getSoundGroupName(target,group,number)) return 2;
 if (!instance->synth->getSoundName(target+8,group,number)) { for(unsigned i=8;i<18;i++)target[i]=' ';target[18]=0; }
 return 0;
}
int stunts_mt32_patch_name(unsigned part, char *target) {
 if (!instance || !target || part > 8) return 1;
 const char *name = instance->synth->getPatchName(part);
 for (unsigned i=0;i<10;i++) target[i]=name[i]; target[10]=0; return 0;
}
void stunts_mt32_main_display() { if(instance)instance->synth->setMainDisplayMode(); }
// Stable UI setting IDs; reads allow the UI to retain the actual Munt defaults.
float stunts_mt32_setting(int id) {
 if (!instance) return -1;
 auto &s = *instance->synth;
 switch(id) {
 case 0:return s.isReverbEnabled(); case 1:return s.isReversedStereoEnabled();
 case 2:return s.getOutputGain(); case 3:return s.getReverbOutputGain();
 case 4:return s.getDACInputMode(); case 5:return s.getMIDIDelayMode();
 case 6:return s.isMT32ReverbCompatibilityMode(); case 7:return s.getMasterVolumeOverride();
 default:if(id>=8 && id<=16)return s.getPartVolumeOverride(id-8);return -1;
 }
}
int stunts_mt32_set(int id, float value) {
 if (!instance || !(value>=0)) return 1;
 auto &s = *instance->synth;
 switch(id) {
 case 0:if(value>1)return 1;s.setReverbEnabled(value!=0);break;
 case 1:if(value>1)return 1;s.setReversedStereoEnabled(value!=0);break;
 case 2:if(value>2)return 1;s.setOutputGain(value);break;
 case 3:if(value>2)return 1;s.setReverbOutputGain(value);break;
 case 4:if(value>3 || value!=int(value))return 1;s.setDACInputMode(MT32Emu::DACInputMode(int(value)));break;
 case 5:if(value>2 || value!=int(value))return 1;s.setMIDIDelayMode(MT32Emu::MIDIDelayMode(int(value)));break;
 case 6:if(value>1)return 1;s.setReverbCompatibilityMode(value!=0);break;
 case 7:if(value>255 || value!=int(value))return 1;s.setMasterVolumeOverride(int(value));break;
 default:if(id<8 || id>16 || value>255 || value!=int(value))return 1;s.setPartVolumeOverride(id-8,int(value));
 }
 return 0;
}
void stunts_mt32_reset_controllers() {
 if (!instance) return;
 for(unsigned part=0;part<9;part++) {
  instance->synth->playMsgOnPart(part,0x0B,0x79,0);
  instance->synth->playMsgOnPart(part,0x0B,0x7B,0);
 }
}
void stunts_mt32_flush() { if(instance)instance->synth->flushMIDIQueue(); }
int stunts_mt32_active() { return instance && instance->synth->isActive() ? 1 : 0; }
uint32_t stunts_mt32_sample_rate() {
  return instance ? instance->synth->getStereoOutputSampleRate() : 0;
}
int stunts_mt32_midi(const uint8_t *bytes, uint32_t length) {
  if (!instance || (!bytes && length)) return 1;
  instance->reporter.overflow = false;
  instance->parser->parseStream(bytes, length);
  return instance->reporter.overflow ? 2 : 0;
}
int stunts_mt32_render(float *stereo, uint32_t frames) {
  if (!instance || !stereo || frames > 65536) return 1;
  instance->synth->render(stereo, frames);
  return 0;
}
}
